package com.melo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.data.model.UserProfile
import com.melo.app.ui.theme.LocalMeloColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onBack: () -> Unit,
    onEditProfile: () -> Unit,
    onSettings: () -> Unit,
    onStories: () -> Unit
) {
    val colors = LocalMeloColors.current
    
    // Демо-профиль
    val profile = remember {
        UserProfile(
            name = "Melo User",
            username = "melo_user",
            bio = "Привет! Это мой профиль в Melo ✨\nОфлайн-мессенджер нового поколения"
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Профиль") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = onEditProfile) {
                        Icon(Icons.Default.Edit, contentDescription = "Редактировать")
                    }
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Настройки")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Banner + Avatar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
            ) {
                // Banner
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    colors.primary.copy(alpha = 0.8f),
                                    colors.primary.copy(alpha = 0.4f),
                                    colors.background
                                )
                            )
                        )
                )
                
                // Avatar
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = 40.dp)
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(colors.surface)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(94.dp)
                            .clip(CircleShape)
                            .background(colors.primary.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = profile.name.first().toString(),
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.primary
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(50.dp))
            
            // Name & username
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = profile.name,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.onBackground
                )
                Text(
                    text = "@${profile.username}",
                    fontSize = 15.sp,
                    color = colors.secondaryText
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Bio
            if (profile.bio.isNotBlank()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = colors.surface)
                ) {
                    Text(
                        text = profile.bio,
                        modifier = Modifier.padding(16.dp),
                        color = colors.onBackground,
                        fontSize = 15.sp
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Actions
            ProfileActionItem(
                icon = Icons.Default.AutoStories,
                title = "Истории",
                subtitle = "Смотреть и добавлять",
                onClick = onStories
            )
            ProfileActionItem(
                icon = Icons.Default.Edit,
                title = "Изменить профиль",
                subtitle = "Имя, фото, описание",
                onClick = onEditProfile
            )
            ProfileActionItem(
                icon = Icons.Default.Settings,
                title = "Настройки",
                subtitle = "Темы, уведомления",
                onClick = onSettings
            )
        }
    }
}

@Composable
fun ProfileActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val colors = LocalMeloColors.current
    
    ListItem(
        headlineContent = { Text(title, color = colors.onBackground) },
        supportingContent = { Text(subtitle, color = colors.secondaryText) },
        leadingContent = {
            Icon(icon, contentDescription = null, tint = colors.primary)
        },
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}

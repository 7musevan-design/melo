package com.melo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.data.model.Message
import com.melo.app.data.model.MessageType
import com.melo.app.ui.theme.LocalMeloColors
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    chatId: String,
    onBack: () -> Unit
) {
    val colors = LocalMeloColors.current
    var messageText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    
    // Демо-сообщения
    val messages = remember {
        mutableStateListOf(
            Message(chatId = chatId, senderId = "other", text = "Привет! Как дела?", isOutgoing = false, timestamp = System.currentTimeMillis() - 600000),
            Message(chatId = chatId, senderId = "me", text = "Нормально, спасибо! А у тебя?", isOutgoing = true, timestamp = System.currentTimeMillis() - 500000),
            Message(chatId = chatId, senderId = "other", text = "Тоже хорошо. Что нового?", isOutgoing = false, timestamp = System.currentTimeMillis() - 400000),
            Message(chatId = chatId, senderId = "me", text = "Делаю новый мессенджер Melo 😎", isOutgoing = true, timestamp = System.currentTimeMillis() - 300000),
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Чат", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Text("в сети", fontSize = 13.sp, color = colors.secondaryText)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = { /* звонок */ }) {
                        Icon(Icons.Default.Call, contentDescription = "Звонок")
                    }
                    IconButton(onClick = { /* ещё */ }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Ещё")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    navigationIconContentColor = colors.onBackground,
                    actionIconContentColor = colors.onBackground
                )
            )
        },
        containerColor = colors.background,
        bottomBar = {
            MessageInputBar(
                text = messageText,
                onTextChange = { messageText = it },
                onSend = {
                    if (messageText.isNotBlank()) {
                        messages.add(
                            Message(
                                chatId = chatId,
                                senderId = "me",
                                text = messageText.trim(),
                                isOutgoing = true
                            )
                        )
                        messageText = ""
                    }
                },
                onAttach = { /* фото / файл */ },
                onVoice = { /* голосовое */ }
            )
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(messages) { message ->
                MessageBubble(message = message)
            }
        }
    }
}

@Composable
fun MessageBubble(message: Message) {
    val colors = LocalMeloColors.current
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isOutgoing) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (message.isOutgoing) 16.dp else 4.dp,
                        bottomEnd = if (message.isOutgoing) 4.dp else 16.dp
                    )
                )
                .background(if (message.isOutgoing) colors.bubbleOut else colors.bubbleIn)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Column {
                Text(
                    text = message.text,
                    color = colors.onBackground,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = timeFormat.format(Date(message.timestamp)),
                    fontSize = 11.sp,
                    color = colors.secondaryText,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
fun MessageInputBar(
    text: String,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onAttach: () -> Unit,
    onVoice: () -> Unit
) {
    val colors = LocalMeloColors.current
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.surface)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onAttach) {
            Icon(Icons.Default.AttachFile, contentDescription = "Прикрепить", tint = colors.secondaryText)
        }
        
        TextField(
            value = text,
            onValueChange = onTextChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Сообщение", color = colors.secondaryText) },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = colors.background,
                unfocusedContainerColor = colors.background,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = colors.onBackground,
                unfocusedTextColor = colors.onBackground
            ),
            shape = RoundedCornerShape(20.dp),
            maxLines = 4
        )
        
        Spacer(modifier = Modifier.width(4.dp))
        
        if (text.isBlank()) {
            IconButton(onClick = onVoice) {
                Icon(Icons.Default.Mic, contentDescription = "Голосовое", tint = colors.primary)
            }
        } else {
            IconButton(onClick = onSend) {
                Icon(Icons.Default.Send, contentDescription = "Отправить", tint = colors.primary)
            }
        }
    }
}

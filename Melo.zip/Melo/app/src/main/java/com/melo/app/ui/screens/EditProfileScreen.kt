package com.melo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.ui.theme.LocalMeloColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val colors = LocalMeloColors.current
    
    var name by remember { mutableStateOf("Melo User") }
    var username by remember { mutableStateOf("melo_user") }
    var bio by remember { mutableStateOf("Привет! Это мой профиль в Melo ✨") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Изменить профиль") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = onSaved) {
                        Icon(Icons.Default.Check, contentDescription = "Сохранить", tint = colors.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    navigationIconContentColor = colors.onBackground
                )
            )
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Banner preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(colors.primary.copy(0.7f), colors.background)
                        )
                    )
            ) {
                // Change banner button
                FilledTonalButton(
                    onClick = { /* выбрать баннер */ },
                    modifier = Modifier
                        .align(Alignment.Center)
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Изменить баннер")
                }
                
                // Avatar
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = 40.dp)
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(colors.surface)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(84.dp)
                            .clip(CircleShape)
                            .background(colors.primary.copy(0.3f))
                    ) {
                        Text(
                            text = name.firstOrNull()?.toString() ?: "M",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.primary
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(56.dp))
            
            // Change avatar button
            TextButton(
                onClick = { /* выбрать аватар */ },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("Изменить фото профиля", color = colors.primary)
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Fields
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Имя") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = textFieldColors()
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.filter { c -> c.isLetterOrDigit() || c == '_' } },
                    label = { Text("Имя пользователя") },
                    prefix = { Text("@") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = textFieldColors()
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text("О себе") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    maxLines = 5,
                    colors = textFieldColors()
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun textFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = LocalMeloColors.current.primary,
    unfocusedBorderColor = LocalMeloColors.current.secondaryText,
    focusedLabelColor = LocalMeloColors.current.primary,
    unfocusedLabelColor = LocalMeloColors.current.secondaryText,
    focusedTextColor = LocalMeloColors.current.onBackground,
    unfocusedTextColor = LocalMeloColors.current.onBackground,
    cursorColor = LocalMeloColors.current.primary
)

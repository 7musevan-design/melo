package com.melo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.melo.app.ui.navigation.MeloNavGraph
import com.melo.app.ui.theme.MeloTheme
import com.melo.app.ui.theme.MeloTheme as ThemeEnum

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            var currentTheme by remember { mutableStateOf(ThemeEnum.DARK) }
            
            MeloTheme(theme = currentTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MeloNavGraph(
                        currentTheme = currentTheme,
                        onThemeChange = { currentTheme = it }
                    )
                }
            }
        }
    }
}

package com.melo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.data.model.Chat
import com.melo.app.data.model.ChatType
import com.melo.app.ui.theme.LocalMeloColors
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatsScreen(
    onChatClick: (String) -> Unit,
    onProfileClick: () -> Unit,
    onNewGroupClick: () -> Unit,
    onStoriesClick: () -> Unit
) {
    val colors = LocalMeloColors.current
    
    // Демо-данные
    val chats = remember {
        listOf(
            Chat(id = "1", title = "Избранное", lastMessage = "Здесь будут важные сообщения", lastMessageTime = System.currentTimeMillis()),
            Chat(id = "2", title = "Семья", type = ChatType.GROUP, lastMessage = "Мама: Купи хлеб", lastMessageTime = System.currentTimeMillis() - 3600000, unreadCount = 3),
            Chat(id = "3", title = "Друзья", type = ChatType.GROUP, lastMessage = "Пойдём гулять?", lastMessageTime = System.currentTimeMillis() - 7200000),
            Chat(id = "4", title = "Рабочий чат", type = ChatType.GROUP, lastMessage = "Встреча в 15:00", lastMessageTime = System.currentTimeMillis() - 86400000),
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Melo",
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )
                },
                actions = {
                    IconButton(onClick = onProfileClick) {
                        Icon(Icons.Default.Person, contentDescription = "Профиль")
                    }
                    IconButton(onClick = { /* поиск */ }) {
                        Icon(Icons.Default.Search, contentDescription = "Поиск")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    actionIconContentColor = colors.onBackground
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNewGroupClick,
                containerColor = colors.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Edit, contentDescription = "Новый чат")
            }
        },
        containerColor = colors.background
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            
            // Stories row
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    StoryItem(
                        title = "Добавить",
                        isAdd = true,
                        onClick = onStoriesClick
                    )
                }
                items(5) { index ->
                    StoryItem(
                        title = "История ${index + 1}",
                        isAdd = false,
                        onClick = onStoriesClick
                    )
                }
            }
            
            Divider(color = colors.divider)
            
            // Chats list
            LazyColumn {
                items(chats) { chat ->
                    ChatListItem(
                        chat = chat,
                        onClick = { onChatClick(chat.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun StoryItem(
    title: String,
    isAdd: Boolean,
    onClick: () -> Unit
) {
    val colors = LocalMeloColors.current
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(
                    if (isAdd) colors.surface else colors.primary.copy(alpha = 0.3f)
                )
        ) {
            if (isAdd) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(28.dp)
                )
            } else {
                Text(
                    text = title.first().toString(),
                    color = colors.onBackground,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            fontSize = 12.sp,
            color = colors.secondaryText,
            maxLines = 1
        )
    }
}

@Composable
fun ChatListItem(
    chat: Chat,
    onClick: () -> Unit
) {
    val colors = LocalMeloColors.current
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(colors.primary.copy(alpha = 0.25f))
        ) {
            Text(
                text = chat.title.first().toString().uppercase(),
                color = colors.primary,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        }
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = chat.title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = colors.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = timeFormat.format(Date(chat.lastMessageTime)),
                    fontSize = 13.sp,
                    color = colors.secondaryText
                )
            }
            
            Spacer(modifier = Modifier.height(3.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = chat.lastMessage,
                    fontSize = 14.sp,
                    color = colors.secondaryText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                
                if (chat.unreadCount > 0) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .padding(start = 6.dp)
                            .background(colors.primary, RoundedCornerShape(12.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = chat.unreadCount.toString(),
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

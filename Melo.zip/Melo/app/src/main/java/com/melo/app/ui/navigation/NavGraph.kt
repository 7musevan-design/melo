package com.melo.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.melo.app.ui.screens.*
import com.melo.app.ui.theme.MeloTheme

sealed class Screen(val route: String) {
    object Chats : Screen("chats")
    object Chat : Screen("chat/{chatId}") {
        fun createRoute(chatId: String) = "chat/$chatId"
    }
    object Profile : Screen("profile")
    object EditProfile : Screen("edit_profile")
    object Settings : Screen("settings")
    object Stories : Screen("stories")
    object CreateStory : Screen("create_story")
    object NewGroup : Screen("new_group")
}

@Composable
fun MeloNavGraph(
    currentTheme: MeloTheme,
    onThemeChange: (MeloTheme) -> Unit
) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Chats.route
    ) {
        composable(Screen.Chats.route) {
            ChatsScreen(
                onChatClick = { chatId ->
                    navController.navigate(Screen.Chat.createRoute(chatId))
                },
                onProfileClick = {
                    navController.navigate(Screen.Profile.route)
                },
                onNewGroupClick = {
                    navController.navigate(Screen.NewGroup.route)
                },
                onStoriesClick = {
                    navController.navigate(Screen.Stories.route)
                }
            )
        }

        composable(
            route = Screen.Chat.route,
            arguments = listOf(navArgument("chatId") { type = NavType.StringType })
        ) { backStackEntry ->
            val chatId = backStackEntry.arguments?.getString("chatId") ?: ""
            ChatScreen(
                chatId = chatId,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Profile.route) {
            ProfileScreen(
                onBack = { navController.popBackStack() },
                onEditProfile = { navController.navigate(Screen.EditProfile.route) },
                onSettings = { navController.navigate(Screen.Settings.route) },
                onStories = { navController.navigate(Screen.Stories.route) }
            )
        }

        composable(Screen.EditProfile.route) {
            EditProfileScreen(
                onBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                currentTheme = currentTheme,
                onThemeChange = onThemeChange,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Stories.route) {
            StoriesScreen(
                onBack = { navController.popBackStack() },
                onCreateStory = { navController.navigate(Screen.CreateStory.route) }
            )
        }

        composable(Screen.CreateStory.route) {
            CreateStoryScreen(
                onBack = { navController.popBackStack() },
                onPublished = { navController.popBackStack() }
            )
        }

        composable(Screen.NewGroup.route) {
            NewGroupScreen(
                onBack = { navController.popBackStack() },
                onCreated = { chatId ->
                    navController.popBackStack()
                    navController.navigate(Screen.Chat.createRoute(chatId))
                }
            )
        }
    }
}

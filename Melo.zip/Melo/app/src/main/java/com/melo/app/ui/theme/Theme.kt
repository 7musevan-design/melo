package com.melo.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class MeloTheme {
    LIGHT, DARK, LIME, PURPLE, ORANGE, MIDNIGHT
}

data class MeloColors(
    val primary: Color,
    val background: Color,
    val surface: Color,
    val onBackground: Color,
    val bubbleOut: Color,
    val bubbleIn: Color,
    val secondaryText: Color,
    val divider: Color
)

val LocalMeloColors = staticCompositionLocalOf {
    MeloColors(
        primary = LightPrimary,
        background = LightBackground,
        surface = LightSurface,
        onBackground = LightOnBackground,
        bubbleOut = LightBubbleOut,
        bubbleIn = LightBubbleIn,
        secondaryText = Color.Gray,
        divider = Color.LightGray
    )
}

fun getMeloColors(theme: MeloTheme): MeloColors {
    return when (theme) {
        MeloTheme.LIGHT -> MeloColors(
            primary = LightPrimary,
            background = LightBackground,
            surface = LightSurface,
            onBackground = LightOnBackground,
            bubbleOut = LightBubbleOut,
            bubbleIn = LightBubbleIn,
            secondaryText = Color(0xFF707579),
            divider = Color(0xFFE7E7E7)
        )
        MeloTheme.DARK -> MeloColors(
            primary = DarkPrimary,
            background = DarkBackground,
            surface = DarkSurface,
            onBackground = DarkOnBackground,
            bubbleOut = DarkBubbleOut,
            bubbleIn = DarkBubbleIn,
            secondaryText = Color(0xFF708499),
            divider = Color(0xFF0E1621)
        )
        MeloTheme.LIME -> MeloColors(
            primary = LimePrimary,
            background = LimeBackground,
            surface = LimeSurface,
            onBackground = LimeOnBackground,
            bubbleOut = LimeBubbleOut,
            bubbleIn = LimeBubbleIn,
            secondaryText = Color(0xFF8FBC8F),
            divider = Color(0xFF1A2E1A)
        )
        MeloTheme.PURPLE -> MeloColors(
            primary = PurplePrimary,
            background = PurpleBackground,
            surface = PurpleSurface,
            onBackground = PurpleOnBackground,
            bubbleOut = PurpleBubbleOut,
            bubbleIn = PurpleBubbleIn,
            secondaryText = Color(0xFFB39DDB),
            divider = Color(0xFF2A2A2A)
        )
        MeloTheme.ORANGE -> MeloColors(
            primary = OrangePrimary,
            background = OrangeBackground,
            surface = OrangeSurface,
            onBackground = OrangeOnBackground,
            bubbleOut = OrangeBubbleOut,
            bubbleIn = OrangeBubbleIn,
            secondaryText = Color(0xFFFFCC80),
            divider = Color(0xFF3E2723)
        )
        MeloTheme.MIDNIGHT -> MeloColors(
            primary = MidnightPrimary,
            background = MidnightBackground,
            surface = MidnightSurface,
            onBackground = MidnightOnBackground,
            bubbleOut = MidnightBubbleOut,
            bubbleIn = MidnightBubbleIn,
            secondaryText = Color(0xFF90CAF9),
            divider = Color(0xFF0D47A1)
        )
    }
}

@Composable
fun MeloTheme(
    theme: MeloTheme = MeloTheme.DARK,
    content: @Composable () -> Unit
) {
    val colors = getMeloColors(theme)
    
    val colorScheme = if (theme == MeloTheme.LIGHT) {
        lightColorScheme(
            primary = colors.primary,
            background = colors.background,
            surface = colors.surface,
            onBackground = colors.onBackground,
            onSurface = colors.onBackground
        )
    } else {
        darkColorScheme(
            primary = colors.primary,
            background = colors.background,
            surface = colors.surface,
            onBackground = colors.onBackground,
            onSurface = colors.onBackground
        )
    }

    CompositionLocalProvider(LocalMeloColors provides colors) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}

package com.melo.app.data.model

import java.util.UUID

// ===== User / Profile =====
data class UserProfile(
    val id: String = "me",
    val name: String = "Melo User",
    val username: String = "melo_user",
    val bio: String = "Привет! Это мой профиль в Melo ✨",
    val avatarPath: String? = null,
    val bannerPath: String? = null,
    val phone: String = ""
)

// ===== Chat =====
enum class ChatType {
    PRIVATE, GROUP
}

data class Chat(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val type: ChatType = ChatType.PRIVATE,
    val avatarPath: String? = null,
    val lastMessage: String = "",
    val lastMessageTime: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val members: List<String> = emptyList(),          // for groups
    val isMuted: Boolean = false
)

// ===== Message =====
enum class MessageType {
    TEXT, IMAGE, VOICE, STICKER, SYSTEM
}

data class Message(
    val id: String = UUID.randomUUID().toString(),
    val chatId: String,
    val senderId: String,
    val type: MessageType = MessageType.TEXT,
    val text: String = "",
    val mediaPath: String? = null,          // photo or voice file
    val voiceDuration: Int = 0,             // seconds
    val timestamp: Long = System.currentTimeMillis(),
    val isOutgoing: Boolean = true,
    val isRead: Boolean = false,
    val replyToId: String? = null
)

// ===== Story =====
data class Story(
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val mediaPath: String,
    val caption: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 24 * 60 * 60 * 1000, // 24 hours
    val viewedBy: List<String> = emptyList()
)

// ===== Sticker =====
data class Sticker(
    val id: String,
    val emoji: String,
    val path: String? = null          // later can be local file
)

// ===== Theme preference =====
data class AppSettings(
    val theme: String = "DARK",       // LIGHT, DARK, LIME, PURPLE, ORANGE, MIDNIGHT
    val notificationsEnabled: Boolean = true
)

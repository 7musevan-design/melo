package com.melo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.ui.theme.LocalMeloColors
import com.melo.app.ui.theme.MeloTheme
import com.melo.app.ui.theme.getMeloColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentTheme: MeloTheme,
    onThemeChange: (MeloTheme) -> Unit,
    onBack: () -> Unit
) {
    val colors = LocalMeloColors.current
    
    val themes = listOf(
        MeloTheme.LIGHT to "Светлая",
        MeloTheme.DARK to "Тёмная",
        MeloTheme.LIME to "Лаймовая",
        MeloTheme.PURPLE to "Фиолетовая",
        MeloTheme.ORANGE to "Оранжевая",
        MeloTheme.MIDNIGHT to "Полночь"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    navigationIconContentColor = colors.onBackground
                )
            )
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "Тема оформления",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.onBackground
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(themes) { (theme, name) ->
                    ThemeCard(
                        theme = theme,
                        name = name,
                        isSelected = currentTheme == theme,
                        onClick = { onThemeChange(theme) }
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            Text(
                text = "Другие настройки",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.onBackground
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    SettingsToggleItem("Уведомления", true)
                    Divider(color = colors.divider)
                    SettingsToggleItem("Звуки", true)
                    Divider(color = colors.divider)
                    SettingsToggleItem("Вибрация", false)
                }
            }
        }
    }
}

@Composable
fun ThemeCard(
    theme: MeloTheme,
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val themeColors = getMeloColors(theme)
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .then(
                if (isSelected) Modifier.border(2.dp, themeColors.primary, RoundedCornerShape(12.dp))
                else Modifier
            )
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(themeColors.background)
                .border(1.dp, Color.Gray.copy(alpha = 0.3f), CircleShape)
        ) {
            // Preview bubbles
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .offset(x = 8.dp)
                    .size(20.dp, 12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(themeColors.bubbleIn)
            )
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .offset(x = (-8).dp)
                    .size(20.dp, 12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(themeColors.bubbleOut)
            )
            
            if (isSelected) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(themeColors.primary)
                ) {
                    Icon(
                        Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(6.dp))
        
        Text(
            text = name,
            fontSize = 13.sp,
            color = LocalMeloColors.current.onBackground
        )
    }
}

@Composable
fun SettingsToggleItem(title: String, initial: Boolean) {
    val colors = LocalMeloColors.current
    var checked by remember { mutableStateOf(initial) }
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = colors.onBackground, fontSize = 16.sp)
        Switch(
            checked = checked,
            onCheckedChange = { checked = it },
            colors = SwitchDefaults.colors(checkedTrackColor = colors.primary)
        )
    }
}
